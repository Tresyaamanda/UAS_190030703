package com.example.novelstore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView TvnamaNovel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TvnamaNovel=findViewById(R.id.tv_nama);
        TvnamaNovel.setText(getIntent().getStringExtra("nama"));
        TvnamaNovel=findViewById(R.id.tv_deskripsi);
        TvnamaNovel.setText(getIntent().getStringExtra("deskripsi"));
        TvnamaNovel=findViewById(R.id.tv_harga);
        TvnamaNovel.setText(getIntent().getStringExtra("harga"));

    }
}
